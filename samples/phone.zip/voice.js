'use strict';
// UI部分
const InitButton = document.getElementById('init');
const ToField = document.getElementById('to');
const CallButton = document.getElementById('call');
const DisconnectButton = document.getElementById('disconnect');

// Twilio.Device
let device;

// 初期化ボタンをクリックした際にアクセストークンを取得し、Twilio.Deviceを初期化する。
InitButton.addEventListener('click', async() => {

});


// 発信ボタンをクリックすると、Twilio.Deviceを用いて通話を開始
dialForm.addEventListener('submit', (event) => {

    event.preventDefault();
    // クリックされたボタンのidを取得
    const submitId = event.submitter.id;
        
});
