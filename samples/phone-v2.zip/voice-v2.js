'use strict';
// UI部分
const InitButton = document.getElementById('init');
const ToField = document.getElementById('to');
const CallButton = document.getElementById('call');
const ConnectButton = document.getElementById('connect');
const DisconnectButton = document.getElementById('disconnect');

// Twilio.Device
let device;
let call;

// 初期化ボタンをクリックした際にアクセストークンを取得し、Twilio.Deviceを初期化する。
InitButton.addEventListener('click', async() => {

    // アクセストークンを取得
    let response = await fetch('/token', {
        method: 'GET',
        headers: {
            'Content-Type' : 'application/json'
        }
    });
    let {token} = await response.json();

    // アクセストークンを用いて初期化
    device = new Twilio.Device(token);

    // Twilio Clientの準備ができた段階で発信ボタンを有効化
    device.on('registered', () => {
        CallButton.disabled = false;
        InitButton.disabled = true;
    });

    // クライアントを登録
    device.register();

});


// 発信ボタンをクリックすると、Twilio.Deviceを用いて通話を開始
dialForm.addEventListener('submit', (event) => {

    event.preventDefault();
    // クリックされたボタンのidを取得
    const submitId = event.submitter.id;

    // 発信ボタンがクリックされた場合はTwiML Appに対して入力された番号に発信してもらう。
    if (submitId === 'call') {
        const number = ToField.value;
        CallButton.disabled = true;
        console.log(number);
        // 番号を指定して発信
        device.connect({
            params: { number: number}
        });
        DisconnectButton.disabled = false;
    }

    // 終了ボタンがクリックされた場合は接続を終了する。
    else if (submitId === 'disconnect') {
        //　全ての接続（通話）を終了
        device.disconnectAll();
        DisconnectButton.disabled = true;
        CallButton.disabled = false; 
    }
        
});