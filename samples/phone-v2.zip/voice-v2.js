'use strict';
// UI部分
const InitButton = document.getElementById('init');
const ToField = document.getElementById('to');
const CallButton = document.getElementById('call');
const ConnectButton = document.getElementById('connect');
const DisconnectButton = document.getElementById('disconnect');

// 初期化ボタンをクリックした際にアクセストークンを取得し、Twilio.Deviceを初期化する。
InitButton.addEventListener('click', async() => {

    // トークンを取得
    let response = await fetch('/token', {
        method: 'GET',
        headers: {
            'Content-Type' : 'application/json'
        }
    });
    let {token}  = await response.json();
    
    // トークンを用いて初期化
    Twilio.Device.setup(token);
    // Twilio Clientの準備ができた段階で発信ボタンを有効化
    Twilio.Device.on('ready', () => {
        CallButton.disabled = false;
        ConnectButton.disabled = true;
        InitButton.disabled = true;
    });

});


// 発信ボタンをクリックすると、Twilio.Deviceを用いて通話を開始
dialForm.addEventListener('submit', (event) => {

    event.preventDefault();

    // クリックされたボタンのidを取得
    const submitId = event.submitter.id;

    // 発信ボタンがクリックされた場合はTwiML Appに対して入力された番号に発信してもらう。
    if (submitId === 'call') {
        const number = ToField.value;
        CallButton.disabled = true;
        // 番号を指定して発信
        Twilio.Device.connect({ number: number});
        DisconnectButton.disabled = false;
    }

    // 終了ボタンがクリックされた場合は接続を終了する。
    else if (submitId === 'disconnect') {
        //　全ての接続（通話）を終了
        Twilio.Device.disconnectAll();
        DisconnectButton.disabled = true;
        ConnectButton.disabled = true;
        CallButton.disabled = false; 
    }

});
